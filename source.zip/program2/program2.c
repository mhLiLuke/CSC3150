#include <linux/module.h>
#include <linux/sched.h>
#include <linux/pid.h>
#include <linux/kthread.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/slab.h>
#include <linux/printk.h>
#include <linux/jiffies.h>
#include <linux/kmod.h>
#include <linux/fs.h>

MODULE_LICENSE("GPL");

extern long _do_fork(unsigned long clone_flags,
      unsigned long stack_start,
      unsigned long stack_size,
      int __user *parent_tidptr,
      int __user *child_tidptr,
      unsigned long tls);
extern void __noreturn do_exit(long code);
extern long do_wait(struct wait_opts *wo);
extern struct filename * getname(const char __user * filename);
EXPORT_SYMBOL_GPL(getname);
extern int do_execve(struct filename *filename,
	  const char __user *const __user *__argv, 
	  const char __user *const __user *__envp);

struct wait_opts {
	enum pid_type		wo_type;
	int			wo_flags;
	struct pid		*wo_pid;

	struct siginfo __user	*wo_info;
	int __user		*wo_stat;
	struct rusage __user	*wo_rusage;

	wait_queue_t		child_wait;
	int			notask_error;
};


static int my_execve(void) {
	int status;
	const char *file_name = "test";
	const char *const argv[] = {file_name, NULL, NULL};
	const char *const envp[] = {"${PATH}", NULL};

	struct filename* my_filename = getname(file_name);

	printk("[program2] : child process");

	status = do_execve(my_filename, argv, envp);
	
	do_exit(status);
}


//implement fork function
int my_fork(void *argc){
	
	
	//set default sigaction for current process
	char *sys_signallist[] = {
		NULL,        // 0
		"SIGHUP",    // 1
		"SIGINT",    // 2
		"SIGQUIT",   // 3
		"SIGILL",    // 4
		"SIGTRAP",   // 5
		"SIGABRT",   // 6
		"SIGBUS",    // 7
		"SIGFPE",    // 8
		"SIGKILL",   // 9
		"SIGUSR1",   // 10
		"SIGUSR2",   // 11
		"SIGPIPE",   // 12
		"SIGALRM",   // 13
		"SIGTERM",   // 14
		"SIGSTKFLT", // 15
		"SIGCHLD",   // 16
		"SIGCONT",   // 17
		"SIGSTOP",   // 18
		"SIGTSTP",   // 19
		"SIGTTIN",   // 20
		"SIGTTOU",   // 21
		"SIGURG",    // 22
		"SIGXCPU",   // 23
		"SIGXFSZ",   // 24
		"SIGVTALRM", // 25
		"SIGPROF",   // 26
		"SIGWINCH",  // 27
		"SIGIO",     // 28
		"SIGPWR",    // 29
		"SIGSYS"     // 30
	};
	int i;
	struct k_sigaction *k_action = &current->sighand->action[0];
	for(i=0;i<_NSIG;i++){
		k_action->sa.sa_handler = SIG_DFL;
		k_action->sa.sa_flags = 0;
		k_action->sa.sa_restorer = NULL;
		sigemptyset(&k_action->sa.sa_mask);
		k_action++;
	}
	
	pid_t child_pid;
	pid_t parent_pid;

	child_pid = _do_fork(SIGCHLD, (unsigned long)&my_execve, 0, NULL, NULL, 0);
	parent_pid = current->pid;

	printk("[program2] : The child process has pid = %d", child_pid);
	printk("[program2] : This is the parent process, pid = %d", parent_pid);

	struct wait_opts *wo = NULL;
	struct waitid_info *wo_info = NULL;
	int status = NULL;

	wo->wo_pid = find_get_pid(child_pid);
	wo->wo_type = PIDTYPE_PID;
	wo->wo_info = wo_info;
	wo->wo_stat = (int __user)status;
	wo->wo_flags = WEXITED | WSTOPPED;
	wo->wo_rusage = NULL;

	do_wait(wo);

	printk("[program2] : get %s signal\n", sys_signallist[(int)wo->wo_stat]);
	printk("[program2] : child process terminated\n");
	printk("[program2] : The return signal is %d\n", (int)wo->wo_stat);

	/* fork a process using kernel_clone or kernel_thread */
	
	/* execute a test program in child process */
	
	/* wait until child process terminates */
	
	return 0;
}

static int __init program2_init(void){

	printk("[program2] : Module_init\n");
	
	/* write your code here */

	/* create a kernel thread to run my_fork */
	struct task_struct *tsk;

	tsk = kthread_create(my_fork, NULL, "my_fork_function");
	printk("[program2] : Module_init create kthread start\n");

	wake_up_process(tsk);
	printk("[program2] : Module_init kthread start\n");

	return 0;
}

static void __exit program2_exit(void){
	printk("[program2] : Module_exit\n");
}

module_init(program2_init);
module_exit(program2_exit);
